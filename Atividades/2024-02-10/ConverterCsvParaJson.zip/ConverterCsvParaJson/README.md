<h1>Atividade</h1>

<p>
Caros alunos, cada equipe responsável por uma disciplina deve baixar o arquivo csv correspondente à sua disciplina e convertê-lo para json usando python, os arquivos em csv estão anexados. Além disso, segue um modelo de código de conversão para servir de suporte para que vocês possam elaborar o seu próprio código. 
</p>

<ul>
    <li>O arquivo EnemVerso.ipynb é um exemplo de algoritmo em python para converter csv em json.</li>
    <li>O arquivo input.csv é um exemplo de dado que deve ser convertido para json</li>
    <li>O arquivo output.json é um exemplo do resultado da conversão feita com o algoritmo</li>
</ul>

<p>Obs.: Qualquer erro nos dados, comunicar ao professor para que possamos corrigir.</p>

<hr>

<p>Data: 10 de fevereiro de 2024 (2024-02-10)</p>